//Is a graphical display of scanned or manually entered item name and price
public class Display {
    //Displays some text on the screen.
    public void displayText(String text) {
        System.out.println("Display: " + text);//Outputs display when called
    }
}
