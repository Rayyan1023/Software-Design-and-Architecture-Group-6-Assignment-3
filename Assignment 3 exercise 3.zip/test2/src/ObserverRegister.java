public interface ObserverRegister {
    void updatedProduct(Product product);
}