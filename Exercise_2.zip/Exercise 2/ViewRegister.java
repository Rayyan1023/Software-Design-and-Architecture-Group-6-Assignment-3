public interface ViewRegister {
    void displayProduct(Product product);
}